^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package stdr_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.3.1 (2016-07-18)
------------------

0.3.0 (2016-07-18)
------------------
* Migrate to package format 2
* Added kinematic model noise parameters support

0.2.0 (2014-07-25)
------------------
* Added messages and services for new sensors. (thermal, CO2, sound, rfid)

0.1.3 (2014-03-25)
------------------

0.1.2 (2014-03-09)
------------------

0.1.1 (2014-02-10)
------------------

0.1.0 (2014-02-06)
------------------
* first public release for Hydro
